@extends('plantillas.plantilla_estudiante')
@section('content')
HISTORICO DEL LUMNO
<div class="card">
    <h5 class="card-header">Curso: Enero - Junio 2020 s8x - Calificacion ###</h5>
    <div class="card-body">

        <div class="card">
            <h5 class="card-header">Unidad 1 - Calificacion ###</h5>
            <div class="card-body">
                <ul>
                    <li>Evidencia 101 - Calificacion ###</li>
                    <li>Evidencia 102 - Calificacion ###</li>
                </ul>

                <ul>
                    <li>Evidencia 103 - Calificacion ###</li>
                    <li>Evidencia 104 - Calificacion ###</li>
                </ul>
            </div>
          </div>
    </div>
  </div>

@endsection
