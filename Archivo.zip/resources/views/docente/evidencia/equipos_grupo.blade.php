@extends('plantillas.plantilla_docente')
@section('content')

<ul>
    <li><a href="/valorar">Equipo 01</a></li>
    <li><a href="/valorar">Equipo 02</a></li>
    <li><a href="/valorar">Equipo 03</a></li>
    <li><a href="/valorar">Equipo 04</a></li>
    <li><a href="/valorar">Equipo 05</a></li>
    <li><a href="/valorar">Equipo 06</a></li>
    <li><a href="/valorar">Equipo 07</a></li>
    <li><a href="/valorar">Equipo 08</a></li>
    <li><a href="/valorar">Equipo 09</a></li>
    <li><a href="/valorar">Equipo 10</a></li>
    <li><a href="/valorar">Equipo 11</a></li>
    <li><a href="/valorar">Equipo 12</a></li>
</ul>
@endsection
