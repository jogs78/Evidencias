<?php $__env->startSection('content'); ?>
    
<?php if(\Session::has('success')): ?>
<div class="alert alert-success alert-dismissible">
  <?php echo e(\Session::get('success')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div><br />
<?php endif; ?>

<?php if(\Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible">
  <?php echo e(\Session::get('error')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div><br />
<?php endif; ?>


<form action="/rubrica/<?php echo e($rubrica->id); ?>" method="post">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
<div class="card">
    <h5 class="card-header">Tipo</h5>
    <div class="card-body">
        <div class="form-group">
            <input class="form-control"  type="text" name="tipo_de" id="tipo_de"  value="<?php echo e($rubrica->tipo_de); ?>">
          </div>
    </div>
</div>
<div class="card">
    <h5 class="card-header">Criterios</h5>
    <div class="card-body">
        <table class="table table-hover">
            <thead>
              <tr>
                <th>Aspecto</th>
                <th>Puntuacion</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rubrica->aspectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aspecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($aspecto->criterio); ?></td>
                    <td><?php echo e($aspecto->ponderacion); ?></td>
                    <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit',  $aspecto)): ?>
                                <a href="/aspecto/<?php echo e($aspecto->id); ?>/edit" class="btn btn-primary"  style="display: inline">Editar</a>                            
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar', $aspecto)): ?>
                            <form action="/aspecto/<?php echo e($aspecto->id); ?>" method="post" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Eliminar</button>
                            </form>
                            <?php endif; ?>
            
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3">SIN ASPECTOS</td>
            </tr>
            <?php endif; ?>
            </tbody>
        </table>
        <a href="/aspecto/create/<?php echo e($rubrica->id); ?>" class="btn btn-success">Agregar criterio</a>
    </div>
</div>
<input class="btn btn-primary"  type="submit" value="Actualizar">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/rubricas/editar_rubrica.blade.php ENDPATH**/ ?>