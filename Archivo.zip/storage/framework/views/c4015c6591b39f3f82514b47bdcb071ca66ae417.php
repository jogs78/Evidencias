<?php $__env->startSection('content'); ?>
<br>
<h5 class="card-title">Lista de "<?php echo e($curso->nombre); ?>" del grupo "<?php echo e($curso->grupo); ?>"</h5><br>

<table class="table" border="1">
    <thead>
        <th>control</th>
        <th>nombre</th>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $curso->estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td></td>
            <td><a href="/historico/<?php echo e($estudiante->id); ?>"><?php echo e($estudiante->name); ?></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2" >Sin estudiantes matriculados</td>
            </tr>
        <?php endif; ?>
     </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/curso/lista.blade.php ENDPATH**/ ?>