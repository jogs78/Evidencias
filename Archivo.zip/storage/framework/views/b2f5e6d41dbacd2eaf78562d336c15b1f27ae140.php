<?php $__env->startSection('content'); ?>

<form action="/aspecto/<?php echo e($aspecto->id); ?>" method="post">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>


<form action="/aspecto/<?php echo e($aspecto->id); ?>" method="post">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <input type="hidden" name="rubrica_id" id="rubrica_id" value="<?php echo e($aspecto->rubrica_id); ?>">
<div class="card">
    <h5 class="card-header">Titulo</h5>
    <div class="card-body">
        <div class="form-group">
            <input class="form-control"  type="text" name="criterio" id="criterio"  value="<?php echo e($aspecto->criterio); ?>">
          </div>
    </div>
</div>
<div class="card">
    <h5 class="card-header">Porcentaje</h5>
    <div class="card-body">
        <div class="form-group">
            <input class="form-control"  type="text" name="ponderacion" id="ponderacion"  value="<?php echo e($aspecto->ponderacion); ?>">
          </div>
    </div>
</div>
<div class="card">
    <h5 class="card-header">Nivel de aceptacion optimo</h5>
    <div class="card-body">
        <div class="form-group">
            <textarea class="form-control" id="aceptacion_optima" name="aceptacion_optima" rows="3"><?php echo e($aspecto->aceptacion_optima); ?></textarea>
          </div>
    </div>
</div>

<div class="card">
    <h5 class="card-header">Nivel de aceptacion media</h5>
    <div class="card-body">
        <div class="form-group">
            <textarea class="form-control" id="aceptacion_media" name="aceptacion_media"  rows="3"><?php echo e($aspecto->aceptacion_media); ?></textarea>
          </div>
    </div>
</div>

<div class="card">
    <h5 class="card-header">Nivel de no aceptacion</h5>
    <div class="card-body">
        <div class="form-group">
            <textarea class="form-control" id="aceptacion_nula" name="aceptacion_nula"  rows="3"><?php echo e($aspecto->aceptacion_nula); ?></textarea>
          </div>
    </div>
</div>

<input class="btn btn-primary"  type="submit" value="Actualizar">
 
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/aspectos/editar_aspecto.blade.php ENDPATH**/ ?>