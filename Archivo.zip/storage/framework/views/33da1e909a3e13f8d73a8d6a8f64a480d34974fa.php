<?php $__env->startSection('content'); ?>
<br>

<h5 class="card-title">Lista de "<?php echo e($activo->nombre); ?>" del grupo "<?php echo e($activo->grupo); ?>"</h5><br>
<?php
 $hoy = date("Y-m-d");            
?>

<div class="alert alert-warning" role="alert">
    <h4 class="alert-heading">Para asignar equipos!</h4>
    <p>Doble click en el número de equipo para modificarlo, presiones escape para cancelar o enter para aceptar.</p>
</div>

<table class="table" border="1" id="lista_matriculas">
    <thead>
        <th>Nombre</th>
        <th>EQUIPO</th>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $activo->estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($estudiante->name); ?>(<?php echo e($estudiante->email); ?>)</td>
            <td>  
                    <div id="<?php echo e($estudiante->pivot->id); ?>" class="equipo">
                        <?php echo e($estudiante->pivot->equipo); ?>

                    </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2" >Sin estudiantes matriculados</td>
            </tr>
        <?php endif; ?>
     </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('codigo'); ?>
<script>
var mostrando_select = false;
$().ready(function(){
    $(".equipo").dblclick(function(event){
        if(mostrando_select) return;
        mid  = this.id;
        eq_a = this.innerText;
        inp  = '<select class="sequipo" id="' + eq_a + '">';
            for(i=1; i<=15; i++)
                inp += '<option value="' + i + '">' + i + '</option>';    
        inp += '<option value="' + eq_a + '" selected>' + eq_a + '</option>';    
        inp += '</select>';
        this.innerHTML = inp;
        mostrando_select = true;
    });

    $("table#lista_matriculas>tbody").on("keydown",  ".sequipo" , function(event) {
            console.log('presiono: ', event.which);
            event.preventDefault();
            if ( event.which == 13 ) {
                var val = this.value;
                var mid = this.parentElement.id;
                console.log('guardar :', val + " '" + mid + "'");
                axios.put('/agrupar/' + mid , {
                                            _token:  '<?php echo e(csrf_token()); ?>',
                                            equipo: val
                                      })
                .then(function (response) {
                    $("div#" +response.data.id ).text(response.data.equipo);
                    console.log(response);
                })
                .catch(function (error) {
                    if(error.response.status==401)alert("Usted no ha iniciado en el sistema");
                    if(error.response.status==500)alert("Error 500 en el sistema");
                    else alert(error.response.data.error);
                    console.log(error);
                })
                mostrando_select = false;
            }else  if ( event.which == 27 ) {
                this.parentElement.innerText = this.id
                mostrando_select = false;
            }
    });

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/curso_activo/equipos.blade.php ENDPATH**/ ?>