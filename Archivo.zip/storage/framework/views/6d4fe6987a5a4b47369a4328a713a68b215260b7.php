<?php $__env->startSection('content'); ?>

<?php if(\Session::has('success')): ?>
<div class="alert alert-success alert-dismissible">
  <?php echo e(\Session::get('success')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div><br />
<?php endif; ?>

<?php if(\Session::has('warning')): ?>
<div class="alert alert-info alert-dismissible">
  <?php echo e(\Session::get('warning')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div><br />
<?php endif; ?>

<?php if(\Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible">
  <?php echo e(\Session::get('error')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div><br />
<?php endif; ?>



Seleccione el grupo con el que trabajará, actualmente esta seleccionado "<?php echo e($activo->nombre); ?> del <?php echo e($activo->grupo); ?>"<br>  
<br>

<table class="table table-hover">
  <thead>
    <tr>
      <th>Periodo</th>
      <th>Materia</th>
      <th>Grupo</th>
      <th>Acciones</th>
    </tr>
  </thead>
  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr <?php if($curso->historico()): ?>
      class="text-muted"
    <?php endif; ?>  >
      <td><?php echo e($curso->_periodo()); ?></td>
      <td><?php echo e($curso->nombre); ?></td>
      <td><a href="/lista/<?php echo e($curso->id); ?>"><?php echo e($curso->grupo); ?></a></td>
      <td>
        <?php if($curso->activo == false): ?>
        <a href="/activar/<?php echo e($curso->id); ?>" class="btn btn-secondary">Activar</a>          
        <?php else: ?>
          Activo            
        <?php endif; ?>
      </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr>
    <td colspan="3">SIN CRUSOS</td>
  </tr>
  <?php endif; ?>

  <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/curso/seleccionar.blade.php ENDPATH**/ ?>