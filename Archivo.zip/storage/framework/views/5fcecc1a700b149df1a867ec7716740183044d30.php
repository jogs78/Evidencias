<?php $__env->startSection('content'); ?>

<?php if(\Session::has('success')): ?>
<div class="alert alert-success alert-dismissible">
  <?php echo e(\Session::get('success')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div><br />
<?php endif; ?>

<?php if(\Session::has('error')): ?>
<div class="alert alert-danger alert-dismissible">
  <?php echo e(\Session::get('error')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div><br />
<?php endif; ?>


<table class="table table-hover">
    <thead>
      <tr>
        <th>Rubrica</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $rubricas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubrica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><a href="/rubrica/<?php echo e($rubrica->id); ?>/edit" ><?php echo e($rubrica->tipo_de); ?></a></td>
            <td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar', $rubrica)): ?>
                <form action="/rubrica/<?php echo e($rubrica->id); ?>" method="post" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
                <?php endif; ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="2">SIN RUBRICAS REGISTRADAS</td>
    </tr>
    <?php endif; ?>
    </tbody>
</table>
<br>
    <a class="btn btn-success" href="/rubrica/create">Crear nueva rubrica</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/rubricas/listar_rubricas.blade.php ENDPATH**/ ?>