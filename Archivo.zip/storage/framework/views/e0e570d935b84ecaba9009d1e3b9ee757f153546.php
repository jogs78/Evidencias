<?php $__env->startSection('content'); ?>
<br>
<h5 class="card-title">Lista del grupo "s8_ de Enero-Junio de 2020"</h5><br>
<ol>
    <li>16270158 - ALBORES JIMENEZ JORGE ALBERTO</a></li>
    <li>15300924 - BARRIOS RODRIGUEZ ISAAC</a></li>
    <li>16270740 - BOLAÑOS CAMERAS RAFAEL ANTONIO</a></li>
    <li>16270745 - CASTELLANOS MARROQUIN JOSE MANUEL</a></li>
    <li>16270167 - CIGARROA DE LOS SANTOS DARINEL</a></li>
    <li>16270170 - COUTIÑO GUILLEN ITZAYANA CAROLINA</a></li>
    <li>16270768 - ESPINOSA TECO JORGE EDUARDO</a></li>
    <li>16270179 - FLORES VELASCO SERGIO FABIAN</a></li>
    <li>15270734 - FONSECA HERNANDEZ ANGEL YAIR</a></li>
    <li>16270775 - GONZALEZ MORALES RICARDO DE JESUS</a></li>
    <li>16270776 - GONZALEZ REYES NANCY WENDY</a></li>
    <li>16270785 - HERNANDEZ JUAREZ MARTHA YARENI</a></li>
    <li>16270786 - JIMENEZ AGUILAR EUGENIA ABELINA</a></li>
    <li>15270161 - LOPEZ GARCIA HECTOR AQUILES</a></li>
    <li>15270185 - LOPEZ LOPEZ EDUARDO</a></li>
    <li>16270792 - LOPEZ LOPEZ MERARY ZARAI</a></li>
    <li>16270195 - LOPEZ VILLARREAL FERNANDO ENRIQUE</a></li>
    <li>16270794 - MARTINEZ PEREZ JORGE DAVID</a></li>
    <li>15270165 - MENDEZ ESCOBAR VICTOR RAUL</a></li>
    <li>16271080 - MORENO TRUJILLO GERARDO ALEJANDRO</a></li>
    <li>15270186 - NAVARRO GOMEZ EDUARDO</a></li>
    <li>15270168 - PEÑA ESPINOSA LUIS ENRIQUE</a></li>
    <li>16270819 - PEÑATE RAMIREZ DIEGO DE JESUS</a></li>
    <li>16270205 - PEREZ JIMENEZ ANTONIO</a></li>
    <li>16270823 - RODRIGUEZ GONZALEZ RAMIRO EUSTAQUIO</a></li>
    <li>16270825 - ROJAS VAZQUEZ ABEL ALEJANDRO</a></li>
    <li>13270614 - ROSALES MALDONADO LUIS FERNANDO</a></li>
    <li>16271203 - TOLEDO FELIPE JOSE ENRIQUE</a></li>
    <li>16270835 - TRUJILLO HERNANDEZ DARWIN ALFREDO</a></li>
    <li>15270799 - VAZQUEZ DE LA CRUZ RODOLFO DE JESUS</a></li>
    <li>16270842 - VIDAL DIAZ SEBASTIAN DE JESUS</a></li>
</ol>
 <a href="/agregar_estudiante" class="btn btn-primary">AGREGAR ESTUDIANTE</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/estudiantes/matricular.blade.php ENDPATH**/ ?>