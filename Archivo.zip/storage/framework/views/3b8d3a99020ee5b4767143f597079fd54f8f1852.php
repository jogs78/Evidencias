<?php $__env->startSection('content'); ?>
formulario donde ponga 
cuanto se asigna por rubro
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/calificar.blade.php ENDPATH**/ ?>