<?php $__env->startSection('content'); ?>
HISTORICO DEL LUMNO
<div class="card">
    <h5 class="card-header">Curso: Enero - Junio 2020 s8x - Calificacion ###</h5>
    <div class="card-body">

        <div class="card">
            <h5 class="card-header">Unidad 1 - Calificacion ###</h5>
            <div class="card-body">
                <ul>
                    <li>Evidencia 101 - Calificacion ###</li>
                    <li>Evidencia 102 - Calificacion ###</li>
                </ul>

                <ul>
                    <li>Evidencia 103 - Calificacion ###</li>
                    <li>Evidencia 104 - Calificacion ###</li>
                </ul>
            </div>
          </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_estudiante', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/estudiante/historicoe.blade.php ENDPATH**/ ?>