<?php $__env->startSection('content'); ?>

<h5 class="card-title">Lista de evidencias para el grupo: "s8_ de Enero-Junio de 2020"</h5><br>

<a class="btn btn-success" href="/dejar">Dejar</a>
<br>
<ul>
    <li><a href="/equipos_grupo">Evidencia 101</a></li>
    <li><a href="/equipos_grupo">Evidencia 102</a></li>
    <li><a href="/equipos_grupo">Evidencia 103</a></li>
    <li><a href="/equipos_grupo">Evidencia 201</a></li>
    <li><a href="/equipos_grupo">Evidencia 202</a></li>
    <li><a href="/equipos_grupo">Evidencia 203</a></li>
    <li><a href="/equipos_grupo">Evidencia 301</a></li>
    <li><a href="/equipos_grupo">Evidencia 302</a></li>
    <li><a href="/equipos_grupo">Evidencia 303</a></li>
    <li><a href="/equipos_grupo">Evidencia 401</a></li>
    <li><a href="/equipos_grupo">Evidencia 402</a></li>
    <li><a href="/equipos_grupo">Evidencia 403</a></li>
</ul>
paginas..........


<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/evidencias/listar_evidencias.blade.php ENDPATH**/ ?>