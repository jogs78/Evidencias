<?php $__env->startSection('content'); ?>

<ul>
    <li><a href="/valorar">Equipo 01</a></li>
    <li><a href="/valorar">Equipo 02</a></li>
    <li><a href="/valorar">Equipo 03</a></li>
    <li><a href="/valorar">Equipo 04</a></li>
    <li><a href="/valorar">Equipo 05</a></li>
    <li><a href="/valorar">Equipo 06</a></li>
    <li><a href="/valorar">Equipo 07</a></li>
    <li><a href="/valorar">Equipo 08</a></li>
    <li><a href="/valorar">Equipo 09</a></li>
    <li><a href="/valorar">Equipo 10</a></li>
    <li><a href="/valorar">Equipo 11</a></li>
    <li><a href="/valorar">Equipo 12</a></li>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/evidencias/equipos_grupo.blade.php ENDPATH**/ ?>