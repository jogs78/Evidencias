<?php $__env->startSection('content'); ?>


<div class="card">
    <h5 class="card-header">Titulo</h5>
    <div class="card-body">
        <div class="form-group">
            <input class="form-control"  type="text" name="" id="">
          </div>
    </div>
</div>
<div class="card">
    <h5 class="card-header">Descripcion</h5>
    <div class="card-body">
        <div class="form-group">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
          </div>
    </div>
</div>
<div class="card">
    <h5 class="card-header">Porcentaje</h5>
    <div class="card-body">
        <div class="form-group">
            <input class="form-control"  type="text" name="" id="">
          </div>
    </div>
</div>
<div class="card">
    <h5 class="card-header">Nivel de aceptacion optimo</h5>
    <div class="card-body">
        <div class="form-group">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
          </div>
    </div>
</div>

<div class="card">
    <h5 class="card-header">Nivel de aceptacion medio</h5>
    <div class="card-body">
        <div class="form-group">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
          </div>
    </div>
</div>

<div class="card">
    <h5 class="card-header">Nivel de no aceptacion</h5>
    <div class="card-body">
        <div class="form-group">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
          </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/rubricas/crear_criterio.blade.php ENDPATH**/ ?>