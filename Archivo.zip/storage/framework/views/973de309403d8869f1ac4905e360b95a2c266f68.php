<?php $__env->startSection('content'); ?>

<h5 class="card-title">Evidencia para el grupo: "<?php echo e($activo->grupo); ?>" del "<?php echo e($activo->_periodo()); ?>" en la materia "<?php echo e($activo->nombre); ?>"</h5><br>
<br>


  <form action="/evidencia/<?php echo e($evidencia->id); ?>" method="POST">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
        <input type="hidden" name="dejado_en" id="dejado_en" value="<?php echo e($activo->id); ?>">
    <label for="titulo">Titulo de la evidencia</label>
    <input type="text" class="form-control" id="titulo"  name="titulo" value="<?php echo e($evidencia->titulo); ?>">
    <label for="rubrica_usada">Rubrica a usar:</label>
    <select class="form-control" name="rubrica_usada" id="rubrica_usada" >
      <?php $__currentLoopData = $rubricas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubrica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($rubrica->id); ?>" <?php if($rubrica->id == $evidencia->rubrica_usada ): ?>
            selected
        <?php endif; ?> ><?php echo e($rubrica->tipo_de); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <label for="unidad">Unidad:</label>
    <input type="number" class="form-control" name="unidad" id="unidad" min="1" max="<?php echo e($activo->unidades); ?>"  value="<?php echo e($evidencia->unidad); ?>">
    <label for="fundamentos">Investigacion</label>
    <textarea class="form-control" id="fundamentos"  name="fundamentos" rows="3"><?php echo e($evidencia->fundamentos); ?></textarea>
    <label for="desarrollo">Desarrollo</label>
    <textarea class="form-control" id="desarrollo"  name="desarrollo" rows="3"><?php echo e($evidencia->desarrollo); ?></textarea>
    <input class="btn btn-primary"  type="submit" value="EDITAR">
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/evidencia/editar.blade.php ENDPATH**/ ?>