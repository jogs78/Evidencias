<?php $__env->startSection('content'); ?>
<form action="/curso/<?php echo e($curso->id); ?>" method="post">
<?php echo method_field('PUT'); ?>
<?php echo csrf_field(); ?>
<div class="card">
    <h5 class="card-header">Curso:  </h5>
    <div class="card-body">
        <div class="form-group">
            <div class="row">
                <div class="col-6">
                    <label for="fecha_inicio">Fecha de Inicio: </label>
                    <input class="form-control"  type="date" name="fecha_inicio" id="fecha_inicio" value="<?php echo e($curso->fecha_inicio); ?>">
                </div>
                <div class="col-6">
                    <label for="fecha_fin">Fecha de finalizacion: </label>
                    <input class="form-control"  type="date" name="fecha_fin" id="fecha_fin" value="<?php echo e($curso->fecha_fin); ?>">
                </div>
            </div>
            <label for="nombre">Materia: </label>
            <input class="form-control"  type="text" name="nombre" id="nombre" value="<?php echo e($curso->nombre); ?>">
            <label for="descripcion">Objetivo General: </label>
            <textarea class="form-control" name="descripcion" id="descripcion" rows="3"><?php echo e($curso->descripcion); ?></textarea>
            <label for="grupo">Grupo: </label>
            <input class="form-control" type="text" name="grupo" id="grupo" value="<?php echo e($curso->grupo); ?>">
            <label for="unidades">Unidades: </label>
            <input class="form-control"  type="number" name="unidades" id="unidades" step="1" min="1" max="6" value="<?php echo e($curso->unidades); ?>">
        </div>
    </div>
</div>
<input class="btn btn-primary"  type="submit" value="Editar">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/curso/editar.blade.php ENDPATH**/ ?>