<?php $__env->startSection('content'); ?>
  <?php $__currentLoopData = $estudiante->cursos_pasados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pasado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
      <div class="card-header">
        <?php echo e($pasado->nombre); ?> - <?php echo e($pasado->grupo); ?>

      </div>
      <div class="card-body">
        Fecha Incio: <?php echo e($pasado->fecha_inicio); ?>        Fecha Fin: <?php echo e($pasado->fecha_inicio); ?><br>
        Calificacion obtenida : <?php echo e($pasado->pivot->calificacion_final); ?>

      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php $__currentLoopData = $estudiante->cursos_actuales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
    <div class="card-header">
      <?php echo e($actual->nombre); ?> - <?php echo e($actual->grupo); ?> 
    </div>
    <div class="card-body">
      <ul>
        <?php $__currentLoopData = $actual->evidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><a href="/entregar/<?php echo e($evidencia->id); ?>"><?php echo e($evidencia->titulo); ?></a></li>          
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_estudiante', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/estudiante/estudiante.blade.php ENDPATH**/ ?>