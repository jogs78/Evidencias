<?php $__env->startSection('content'); ?>

<h5 class="card-title">Evidencia para el grupo: "<?php echo e($activo->grupo); ?>" del "<?php echo e($activo->_periodo()); ?>" en la materia "<?php echo e($activo->nombre); ?>"</h5><br>
<br>


  <form action="/evidencia" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="dejado_en" id="dejado_en" value="<?php echo e($activo->id); ?>">
    <label for="titulo">Titulo de la evidencia</label>
    <input type="text" class="form-control" id="titulo"  name="titulo">
    <label for="rubrica_usada">Rubrica a usar:</label>
    <select class="form-control" name="rubrica_usada" id="rubrica_usada">
      <?php $__currentLoopData = $rubricas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubrica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($rubrica->id); ?>"><?php echo e($rubrica->tipo_de); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <label for="unidad">Unidad:</label>
    <input type="number" class="form-control" name="unidad" id="unidad" min="1" max="<?php echo e($activo->unidades); ?>">
    <label for="fundamentos">Investigacion</label>
    <textarea class="form-control" id="fundamentos"  name="fundamentos" rows="3"></textarea>
    <label for="desarrollo">Desarrollo</label>
    <textarea class="form-control" id="desarrollo"  name="desarrollo" rows="3"></textarea>
    <input class="btn btn-primary"  type="submit" value="Crear">
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/evidencia/dejar.blade.php ENDPATH**/ ?>