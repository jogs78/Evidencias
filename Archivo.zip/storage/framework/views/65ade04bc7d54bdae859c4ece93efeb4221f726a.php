<?php $__env->startSection('content'); ?>

<?php if(\Session::has('success')): ?>
<div class="alert alert-success">
  <p><?php echo e(\Session::get('success')); ?></p>
</div><br />
<?php endif; ?>

<?php if(\Session::has('error')): ?>
<div class="alert alert-danger">
  <p><?php echo e(\Session::get('error')); ?></p>
</div><br />
<?php endif; ?>

<h5 class="card-title">Lista de evidencias para el grupo: "<?php echo e($activo->grupo); ?>" del "<?php echo e($activo->_periodo()); ?>" en la materia "<?php echo e($activo->nombre); ?>"</h5><br>
<br>

<table class="table table-hover">
  <thead>
    <tr>
      <th>Evidencia</th>
      <th>Acciones</th>
    </tr>
  </thead>
  <tbody>
  <?php $__empty_1 = true; $__currentLoopData = $evidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <td><?php echo e($evidencia->titulo); ?></td>
      <td>
        <a href="/evidencia/<?php echo e($evidencia->id); ?>/edit" class="btn btn-primary"  style="display: inline">Editar</a>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eliminar', $evidencia)): ?>
            <form action="/evidencia/<?php echo e($evidencia->id); ?>" method="post"  style="display: inline">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger">Eliminar</button>
            </form>              
          <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr>
    <td colspan="2">SIN EVIDENCIAS</td>
  </tr>
  <?php endif; ?>
  </tbody>
</table>
<a href="evidencia/create" class="btn btn-success">CREAR</a>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/evidencia/listar.blade.php ENDPATH**/ ?>