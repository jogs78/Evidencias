<?php $__env->startSection('content'); ?>
Seleccione el grupo con el que trabajará<br>
<table class="table table-hover">
    <thead>
      <tr>
        <th>Periodo</th>
        <th>Grupo</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Agosto - Diciembre 2193</td>
        <td><a href="/lista">s8a</a></td>
        <td>
          <button class="btn btn-primary">Editar</button>
          <button class="btn btn-secondary">Activar</button>
          <a href="/agregar_alumnos" class="btn btn-info">Agregar Alumnos</a>
          <button class="btn btn-danger">Eliminar</button>
        </td>
      </tr>
      <tr>
        <td>Agosto - Diciembre 2193</td>
        <td><a href="/lista">s8a</a></td>
        <td>
          <button class="btn btn-primary">Editar</button>
          <button class="btn btn-secondary">Activar</button>
          <a href="/agregar_alumnos" class="btn btn-info">Agregar Alumnos</a>
          <button class="btn btn-danger">Eliminar</button>
        </td>
      </tr>
      <tr>
        <td>Enero - Junio de 2201</td>
        <td><a href="/lista">s8a</a></td>
        <td>
          <button class="btn btn-primary">Editar</button>
          <button class="btn btn-secondary">Activar</button>
          <a href="/agregar_alumnos" class="btn btn-info">Agregar Alumnos</a>
          <button class="btn btn-danger">Eliminar</button>
        </td>
      </tr>
      <tr>
        <td>2201</td>
        <td><a href="/lista">s8a</a></td>
        <td>
          <button class="btn btn-primary">Editar</button>
          <button class="btn btn-secondary">Activar</button>
          <a href="/agregar_alumnos" class="btn btn-info">Agregar Alumnos</a>
          <button class="btn btn-danger">Eliminar</button>
        </td>
      </tr>
    </tbody>
  </table>
  <button class="btn btn-success">AGREGAR</button>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/grupos/grupo.blade.php ENDPATH**/ ?>