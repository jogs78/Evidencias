<?php $__env->startSection('content'); ?>
<?php if(\Session::has('success')): ?>
<div class="alert alert-success">
  <p><?php echo e(\Session::get('success')); ?></p>
</div><br />
<?php endif; ?>
<?php if(\Session::has('error')): ?>
<div class="alert alert-danger">
  <p><?php echo e(\Session::get('error')); ?></p>
</div><br />
<?php endif; ?>
Titulo: <?php echo e($evidencia->titulo); ?>

<p>Fundamentos:<br><?php echo e($evidencia->fundamentos); ?></p> 
<p>Desarrollo:<br><?php echo e($evidencia->desarrollo); ?></p> 
<hr>
<?php if(is_null($asignacion->archivo_entregado)): ?>
  <form action="/entregar/<?php echo e($evidencia->id); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    Evidencia: <input type="file" name="archivo_entregado" id="archivo_entregado">
    <input type="submit" accept="application/pdf" value="Entregar">
  </form>
<?php else: ?>
  <p>Fecha de entrega:<br><?php echo e($asignacion->cuando_entrego); ?></p> 
  <?php if(!is_null($asignacion->calificacion)): ?>
    <p>Calificacion:<br><?php echo e($asignacion->calificacion); ?></p>     
  <?php endif; ?>
  <?php if(!is_null($asignacion->observaciones)): ?>
    <p>Observaciones:<br><?php echo e($asignacion->observaciones); ?></p>     
  <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla_estudiante', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/estudiante/entregar.blade.php ENDPATH**/ ?>