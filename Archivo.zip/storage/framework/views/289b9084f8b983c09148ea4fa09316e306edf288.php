<?php $__env->startSection('content'); ?>
<br>

<h5 class="card-title">Lista de "<?php echo e($activo->nombre); ?>" del grupo "<?php echo e($activo->grupo); ?>"</h5><br>
<?php
 $hoy = date("Y-m-d");            
?>

<table class="table" border="1" id="lista_matriculas">
    <thead>
        <th>Nombre</th>
        <th>FECHA: <input type="date" name="fecha" id="fecha" value="<?php echo e($hoy); ?>"> </th>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $activo->estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($estudiante->name); ?>(<?php echo e($estudiante->email); ?>)</td>
            <td>  
                    <div id="<?php echo e($estudiante->pivot->id); ?>">
                        <input type="button" name="asistencia" class="btn btn-success asistencia" value="ASISTENCIA">
                        <input type="button" name="asistencia" class="btn btn-danger asistencia"  value="FALTA">
                    </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2" >Sin estudiantes matriculados</td>
            </tr>
        <?php endif; ?>
     </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('codigo'); ?>
<script>
$().ready(function(){
    $(".asistencia").click(function(event){
        mid = this.parentElement.id;
        tipo = this.value;
        valor = false;
        if (tipo == "ASISTENCIA") valor = true;
        //se pone asistencia a la maticulacion
        axios.post('/asistencia/' + mid , {
                                               
                                                    _token:  '<?php echo e(csrf_token()); ?>',
                                                    fecha: $("#fecha").val(),
                                                    asistencia : valor
                                               
                                           })
        .then(function (response) {
          
            if (response.data.asistencia == true) 
                txt = '<p class="text-success">ASISTENCIA</p>';
            else
                txt = '<p class="text-danger">FALTA</p>';

            $('div#' + response.data.matriculacion ).html(txt);
            console.log(response);
        })
        .catch(function (error) {
            if(error.response.status==401)alert("Usted no ha iniciado en el sistema");
            if(error.response.status==500)alert("Error 500 en el sistema");
            else alert(error.response.data.error);
            console.log(error);
        })   
    });


});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/curso_activo/pasar_lista.blade.php ENDPATH**/ ?>