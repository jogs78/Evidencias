<?php $__env->startSection('content'); ?>

<form action="/rubrica" method="post">
    <?php echo csrf_field(); ?>
<div class="card">
    <h5 class="card-header">Tipo</h5>
    <div class="card-body">
        <div class="form-group">
            <input class="form-control"  type="text" name="tipo_de" id="tipo_de">
          </div>
    </div>
</div>
<div class="card">
    <h5 class="card-header">Criterios</h5>
    <div class="card-body">
        Los aspectos (creterios), podrá especificarlos al momento de editar la rubrica
    </div>
</div>
<input class="btn btn-primary"  type="submit" value="Crear">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/rubricas/crear_rubrica.blade.php ENDPATH**/ ?>