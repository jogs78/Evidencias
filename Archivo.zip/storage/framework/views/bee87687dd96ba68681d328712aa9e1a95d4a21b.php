<?php $__env->startSection('content'); ?>


<div class="card">
    <h5 class="card-header">Estudiante</h5>
    <div class="card-body">

        <div class="form-group">
            <label for="exampleFormControlInput1">Numero de control</label>
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="">
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Nombre</label>
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="">
        </div>
    </div>
</div>
<a href="/matricular" class="btn btn-primary">Agregar</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/estudiantes/agregar_estudiante.blade.php ENDPATH**/ ?>