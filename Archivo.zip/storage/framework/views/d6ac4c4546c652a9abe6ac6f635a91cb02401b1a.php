<?php $__env->startSection('content'); ?>

<table class="table table-hover">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Periodo</th>
        <th scope="col">Grupo</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td>2193</td>
        <td>s8a</td>
        <td>@mdo</td>
      </tr>
      <tr>
        <th scope="row">2</th>
        <td>2193</td>
        <td>s8b</td>
        <td>@fat</td>
      </tr>
      <tr>
        <th scope="row">3</th>
        <td>2201</td>
        <td>s8a</td>
        <td>@mdo</td>
      </tr>
      <tr>
        <th scope="row">4</th>
        <td>2201</td>
        <td>s8b</td>
        <td>@fat</td>
      </tr>
    </tbody>
  </table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/grupos.blade.php ENDPATH**/ ?>