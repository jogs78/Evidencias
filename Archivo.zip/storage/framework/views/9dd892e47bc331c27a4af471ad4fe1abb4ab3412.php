<?php $__env->startSection('content'); ?>
<form>
    <div class="form-group">
      <label for="exampleFormControlInput1">Titulo de la evidencia</label>
      <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
    </div>
    <div class="form-group">
        <label for="exampleFormControlTextarea1">Observaciones</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
      </div>
      <div class="form-group">
        <label for="exampleFormControlTextarea1">Calificacion</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
      </div>
      
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/calificar.blade.php ENDPATH**/ ?>