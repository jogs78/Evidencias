<?php $__env->startSection('content'); ?>
<div class="card">
    <h5 class="card-header">Matricular estudiante en el curso de "<?php echo e($curso->nombre); ?>" del grupo "<?php echo e($curso->grupo); ?>"</h5>
    <div class="card-body">
        <div class="form-group">
            <label for="control">Numero de control</label>
            <input type="text" class="form-control" id="control" name="control" placeholder="">
        </div>
    </div>
</div>
<a href="/matricular" class="btn btn-primary">Agregar</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla_docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/evidencias/resources/views/docente/curso/matricular.blade.php ENDPATH**/ ?>